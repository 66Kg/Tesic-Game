import java.awt.Insets;

import game.config.CanvasConfig;
import game.control.GameController;
import game.util.PlayerRecord;
import game.view.FrameGame;
import game.view.Framewelcome;

/**
 * 
 */

/**
 * @author wangyao
 *
 */
public class GameEntry {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		//FrameGame frame= new FrameGame();
//		GameController game=new GameController();
//		game.showwindow();
//		PlayerRecord.getPlayer(0, null);
//		PlayerRecord.getPlayer(1, null);
        Framewelcome wel=new Framewelcome();
        wel.welcomeJFrame();
//    
	}

}
