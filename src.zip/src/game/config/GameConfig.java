/**
 * 
 */
package game.config;

import java.awt.Toolkit;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import javax.imageio.stream.FileImageInputStream;

/**
 * @author wangyao
 *��Ϸ����
 */
public class GameConfig {
	public static final int ROWS;//����������д 
	public static final int COLS;
	public static final int TIME_SLICE;
	public static int unit;//���굥λ
	private static int speed;
	private static String skinPath;
	private static String language;
	private static String pattern;
	private static  Properties cfg;
	static{
		try {
			cfg=new Properties();
			cfg.load(new FileInputStream("cfgs/game.ini"));
		} catch (Exception e) {
			// TODO: handle exception
		}
		skinPath= cfg.getProperty("skin");
		ROWS =Integer.parseInt(cfg.getProperty("rows"));
		speed =Integer.parseInt(cfg.getProperty("speed"));
		COLS =Integer.parseInt(cfg.getProperty("cols"));
		TIME_SLICE=Integer.parseInt(cfg.getProperty("timeslice"));
		unit= Integer.parseInt(cfg.getProperty("unit"));
		language=cfg.getProperty("language");
		pattern=cfg.getProperty("pattern");
		if(Toolkit.getDefaultToolkit().getScreenSize().height<900)//�жϽ����Ƿ�С����Ļ�߶�
			unit =(unit*3)/4;
	}

	public static int getSpeed() {
		return speed;
	}
	public static void setSpeed(int speed) {
		GameConfig.speed = speed;
	}
	public static void save(){
		try {
			cfg.store(new FileOutputStream("cfgs/game.ini"),"configs");
		} catch (Exception e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		} 
		
	}
	public static int getCellSize(){
		return unit*4;
	}
	public static String getLanguage() {
		return language;
	}

	public static void setLanguage(String language) {
		GameConfig.language = language;
		cfg.setProperty("language", language);
	}

	public static int getUnit() {
		return unit;
	}

	//get set�����ṩ�����ӿ�
	public static String getSkinPath() {
		return skinPath;
	}

	public static void setSkinPath(String skinPath) {
		GameConfig.skinPath = skinPath;
		cfg.setProperty("skin", skinPath);
	}
	public static String getPattern() {
		return pattern;
	}
	public static void setPattern(String pattern) {
		GameConfig.pattern = pattern;
		cfg.setProperty("pattern", pattern);
	}
	
}
