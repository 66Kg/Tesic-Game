/**
 * 
 */
package game.config;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.swing.text.Document;

import org.dom4j.Element;
import org.dom4j.io.SAXReader;

/**
 * @author wangyao
 *
 */
public class CanvasConfig {

	private static int width;
	private static int height;
	private static ArrayList<LayerConfig>Layers;
	static
	{	try {
			SAXReader reader=new SAXReader();
			org.dom4j.Document document= reader.read(new File("cfgs/canvas.xml"));
			Element window =document.elementByID(GameConfig.getPattern());
			width=Integer.parseInt(window.attributeValue("width"));
			height=Integer.parseInt(window.attributeValue("height"));
			Layers=new ArrayList<LayerConfig>();
			List<Element> elements=window.elements("layer");
			for(Element element :elements){
				Layers.add(new LayerConfig(element));}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//���������ļ�
	public static void Rest(){	
		try {
		SAXReader reader=new SAXReader();
		org.dom4j.Document document= reader.read(new File("cfgs/canvas.xml"));
		Element window =document.elementByID(GameConfig.getPattern());
		width=Integer.parseInt(window.attributeValue("width"));
		height=Integer.parseInt(window.attributeValue("height"));
		Layers=new ArrayList<LayerConfig>();
		List<Element> elements=window.elements("layer");
		for(Element element :elements){
			Layers.add(new LayerConfig(element));}
	} catch (Exception e) {
		e.printStackTrace();
	}
}
	//���ؿͻ������ڿ��ȣ�����Ϊ��λ
	public static  int getWidth() {
		return width*GameConfig.getUnit();
	}
	//���ؿͻ������ڸ߶ȣ�����Ϊ��λ
	public static int getHeight() {
		return height*GameConfig.getUnit();
	}
	public static ArrayList<LayerConfig> getLayers() {
		return Layers;
	}
	
}
