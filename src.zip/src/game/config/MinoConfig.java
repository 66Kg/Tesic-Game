/**
 * 
 */
package game.config;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import game.model.MinoColor;
import game.util.Point;

/**
 * @author wangyao
 *
 */
public class MinoConfig {
private String name;
private MinoColor color;
private int width;
private int height;
private Point []coords;
private static ArrayList<MinoConfig> cfgs;
static{try {
	SAXReader reader=new SAXReader();
    org.dom4j.Document document=reader.read(new File("cfgs/mino.xml"));
    Element root=document.getRootElement();
    List<Element>minos=root.elements();
    cfgs=new ArrayList<MinoConfig>();
    for(Element element:minos){
	MinoConfig mc=new MinoConfig();
	mc.name=element.attributeValue("name");
	mc.color=Enum.valueOf(MinoColor.class,element.attributeValue("color") );
	mc.width=Integer.parseInt(element.attributeValue("w"));
	mc.height=Integer.parseInt(element.attributeValue("h"));
	List<Element>bricks=element.elements();
	mc.coords=new Point[bricks.size()];
	int i=0;
	for(Element e:bricks){
		int x=Integer.parseInt(e.attributeValue("x"));
		int y=Integer.parseInt(e.attributeValue("y"));
		mc.coords[i]=new Point(x, y);
		
		i++;
	}
	cfgs.add(mc);
	
}

	
} catch (Exception e) {e.printStackTrace();}
	// TODO: handle exception
}
public String getName() {
	return name;
}
public MinoColor getColor() {
	return color;
}
public int getWidth() {
	return width;
}
public int getHeight() {
	return height;
}
public Point[] getCoords() {
	return coords;
}
public static ArrayList<MinoConfig> getCfgs() {
	return cfgs;
}



}
