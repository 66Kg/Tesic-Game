package game.model;

public interface RecordListener {
	void refresh(int rows);

}
