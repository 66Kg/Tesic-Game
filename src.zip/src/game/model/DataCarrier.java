/**
 * 
 */
package game.model;

import game.util.PlayerRecord;
import game.view.FrameGame;
import game.view.LayerGame;
import game.view.Player;

import java.awt.Graphics;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.text.View;

import com.sun.org.apache.bcel.internal.generic.NEW;

import sun.java2d.loops.DrawGlyphList;



/**
 * @author wangyao
 *��Ϸ�������壬�ڽ������Ϸҵ�����д���
 *������Ϸǽ����ǰ���飬��һ�飬��Ϸ��Ϣ
 */
public class DataCarrier {
 private TetrisMino current;//��ǰ����
 private TetrisMino next;
 private TetrisWall wall;
 private TetrisMino shadowMino;
 private GameRecord record=new GameRecord();//��̬newһ��ֻ��ˢһ�μ�һ�����
 private boolean pause=false;//��ͣ
 private boolean over=false;
 private  String name;
 

public void imit() {
	current=TetrisMinoFactory.create();//������ǰ����
	 next=TetrisMinoFactory.create();//������һ�鷽��
	 current.center();
	 shadowMino=(TetrisMino)current.clone();
	 wall=new TetrisWall();
	 //�����¼�
	 wall.addRecordListener(new RecordListener() {
		
		@Override
		public void refresh(int rows) {
			// TODO �Զ����ɵķ������
			record.modify(rows);
		}
	});
	 pause=false;
	 over=false;
	 record.reset();
}

public boolean moveMino(int xOffset,int yOffeset){
 	if(!wall.check(current.preMove(xOffset, yOffeset)))return false;
 	current.move(xOffset, yOffeset);
 	shadowMino=(TetrisMino)current.clone();//�ƶ���Ӱ
 	return true;
}//���洦���Ƿ��ƶ�
private boolean moveShadow(int xOffset, int yOffeset) {
	if(!wall.check(shadowMino.preMove(xOffset, yOffeset)))return false;
 	shadowMino.move(xOffset, yOffeset);
	return true;
}//������Ӱ�����Ƿ��ƶ�

public  TetrisMino getShadow(){
	if(shadowMino!=null)
		while(moveShadow(0, 1));
	return shadowMino;
}

public void rotate(){
	if (wall.check(current.preRotate()))
		current.rotate();
	   shadowMino=(TetrisMino)current.clone();
}
public void landed (){
	wall.landed(current.getBricks());
	current=next;
	current.center();
	shadowMino=(TetrisMino)current.clone();
	next=TetrisMinoFactory.create();
	
	if(!wall.check(current.getBricks()))
	{   wall.damaged();
	   current.damaged();
	   over =true;   
	  // System.out.println("dsf");
	   name = JOptionPane.showInputDialog("����������:");
	   Player player =new Player();
	   player.setName(name);
	   player.setScore(record.getScore());
	   PlayerRecord.setPlayer(player);
	   //��Ϣд����±�
	}
	 	}
	


public int getPoints(){
	
	return record.getScore();
}
public  String getName(){
	return name;
}
public TetrisMino getCurrent() {
	return current;
}
public TetrisMino getNext() {
	return next;
}
public TetrisWall getWall() {
	return wall;
	
}
public GameRecord getRecord(){
	return record;
}
public boolean isPause() {
	return pause;
}
public void setOver(boolean over) {
	this.over = over;
}
public boolean isOver() {
	return over;
}
public void setPause(boolean pause) {
	this.pause = pause;
}
}
