package game.model;

public enum MinoColor {
OShape,
IShape,
LShape,
ZShape,
SShape,
JShape,
TShape,
Damaged
}
