/**
 * 
 */
package game.model;

import game.config.GameConfig;
import game.util.SoundPlayer;
import game.view.LayerGame;

/**
 * @author wangyao
 *��Ϸ������㣬�����ṩ��Ϸҵ��������н�
 *��Ϸ������Ϸǽ
 */
public class TetrisServer {
	private DataCarrier carrier;
	private Thread pThread;//����̣߳�
	private PlayerRunner runner;
	private class PlayerRunner implements Runnable{//runnabl �߳�ִ�еĲ�����ִ������
//private boolean running=true;
//public void setStop(){
	//running=false;
//}
		@Override
		public void run() {
			// TODO �Զ����ɵķ������
			while(true){
				try {
					Thread.sleep(GameConfig.TIME_SLICE*GameConfig.getSpeed());
					drop();
				} catch (Exception e) {
					// TODO: handle exception
				}
			}
		}

	}
	public TetrisServer(DataCarrier carrier){
	
	this.carrier=carrier;
	runner=new PlayerRunner();
	pThread=new Thread(runner);
	pThread.setDaemon(true);
	//start();
		
	}
	public void start(){
		if(pThread!=null&&pThread.isAlive())return ;
		pThread.start();
	}
	public void move(int xOffset){
		if(carrier.isPause()||carrier.isOver())return;
		carrier.moveMino(xOffset, 0);
		SoundPlayer.play("move");
	}//ֻ������
	public void drop(){
		if(carrier.isPause()||carrier.isOver())return;
		if(!carrier.moveMino(0, 1))
			carrier.landed();
		
	}//����
	//ֱ�ӽ���
	public void instant(){
		if(carrier.isPause()||carrier.isOver())return;
		while (carrier.moveMino(0, 1));
		carrier.landed();
		SoundPlayer.play("instant");
	}
	public void rotate(){
		if(carrier.isPause()||carrier.isOver())return;
		carrier.rotate();
		SoundPlayer.play("rotate");
	}
	public void pause(){
		carrier.setPause(!carrier.isPause());
		}//!ȡ���ٱ�������

}
