/**
 * 
 */
package game.model;

import java.awt.Graphics;
import java.awt.Image;

import javax.jws.soap.SOAPBinding.ParameterStyle;

import game.config.GameConfig;
import game.config.MinoConfig;
import game.util.GameImage;
import game.util.Point;

/**
 * @author wangyao
 *��Ϸ���飬����brick����
 *�ṩ�ƶ���ת��Ԥ�ƶ�Ԥ��ת
 */
public abstract class TetrisMino implements Cloneable{//��¡�ӿ�
	private DataCarrier carrier;
	private TetrisBrick[] bricks;
	private int width;
	private int height;
	protected double angle=Math.PI/2;
	protected abstract void turn();
	public TetrisMino(TetrisBrick[] a,int w,int h){
		this.bricks=a;
		this.width=w;
		this.height=h;
	}

	@Override
	protected Object clone()  {
		TetrisMino mino=null;
		try {mino=(TetrisMino)super.clone();
		TetrisBrick[] dest=new TetrisBrick[bricks.length];
		int i=0;
		for(TetrisBrick brick:bricks){
			dest[i++]=(TetrisBrick)brick.clone();
		}
		mino.bricks=dest;

		} catch (Exception e) {
			// TODO: handle exception
		}
		// TODO �Զ����ɵķ������
		return mino;	
	}

	public void move(int xOffset,int yOffset)
	{    //TODO:�����ƶ�����δ���
		synchronized (this) {
			for(TetrisBrick brick: bricks){
			brick.setColumn(brick.getColumn()+xOffset);
			brick.setRow(brick.getRow()+yOffset);
		}
			
		}
		
	}
	public TetrisBrick[] preMove(int xOffset,int yOffset){
		TetrisMino mino=(TetrisMino)clone();
		mino.move(xOffset, yOffset);

		return mino.bricks;
	}
	
	public void rotate(){
		synchronized (this) {
			int x0=bricks[0].getColumn();
		int y0=bricks[0].getRow();
		for(TetrisBrick brick:bricks){
			int x1=x0+(int)(Math.sin(angle))*(brick.getRow()-y0)
					+(int)(Math.cos(angle))*(brick.getColumn()-x0);
			int y1=y0+(int)(Math.cos(angle))*(brick.getRow()-y0)
					-(int)(Math.sin(angle))*(brick.getColumn()-x0);
			brick.setColumn(x1);
			brick.setRow(y1);
		}
		turn();
			
		}
			
	}
	public TetrisBrick[] preRotate(){
		TetrisMino mino=(TetrisMino)clone();
		mino.rotate();
		return mino.bricks;
	}
	public void damaged(){
		for(TetrisBrick b:bricks)
			b.damaged();
	}
	public void center(){
		int xoffset=5-bricks[0].getColumn();//ƫ����xoffset
		for(TetrisBrick brick:bricks)
		{
			brick.setColumn(brick.getColumn()+xoffset);
			

		}
	}

	//public TetrisMino(){
	////	bricks=new TetrisBrick[4];
	////	int i=0;
	////	bricks[i++]=new TetrisBrick(1, 0, MinoColor.ZShape);
	////	bricks[i++]=new TetrisBrick(0, 0, MinoColor.ZShape);
	////	bricks[i++]=new TetrisBrick(1, 1, MinoColor.ZShape);
	////	bricks[i++]=new TetrisBrick(2, 1, MinoColor.ZShape);
	////	width=3;
	////	height=2;
	////	
	//	MinoConfig mc =MinoConfig.getCfgs().get(6);
	//	width=mc.getWidth();
	//	height=mc.getHeight();
	//	bricks=new TetrisBrick[mc.getCoords().length];
	//	int i=0;
	//	for(Point pt:mc.getCoords()){
	//		bricks[i]=new TetrisBrick(pt.getX(), pt.getY(),mc.getColor());
	//		i++;
	//	}
	//	
	//}//��ʼ��bricks

	//��ȡmino�Ŀ��ȣ����ص�λ
	public int getWidth() {
		return width*4*GameConfig.getUnit();
	}
	//��ȡmino�ĸ߶ȣ����ص�λ
	public int getHeight() {
		return height*4*GameConfig.getUnit();
	}
	//��ȡ���mino��С��������
	public TetrisBrick[] getBricks() {
		return bricks;
	}

}
