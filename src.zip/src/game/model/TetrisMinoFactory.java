/**
 * 
 */
package game.model;

import java.lang.reflect.Constructor;
import java.util.Random;

import game.config.MinoConfig;
import game.util.Point;

/**
 * @author wangyao
 *
 */
public class TetrisMinoFactory implements Cloneable{
	private static TetrisMino[] minos;
	static{
		try {
			minos=new TetrisMino[MinoConfig.getCfgs().size()];
			int i=0;
			for(MinoConfig mc:MinoConfig.getCfgs()){
				Class<?>cls=Class.forName(mc.getName());
				Constructor<?>ctor=cls.getConstructor(TetrisBrick[].class,int.class,int.class);
				TetrisBrick[] bricks =new TetrisBrick[mc.getCoords().length];
				int j=0;
				for(Point pt:mc.getCoords()){
					bricks[j++]=new TetrisBrick(pt.getX(), pt.getY(), mc.getColor());//��ʼ��bricks
				}
				minos[i++]=(TetrisMino)ctor.newInstance(bricks,mc.getWidth(),mc.getHeight());
			}
		} catch (Exception e)
		{e.printStackTrace();
		// TODO: handle exception
		}
	}
	public static TetrisMino create(){
		Random random=new Random();
		int index=random.nextInt(minos.length);
		return (TetrisMino)minos[index].clone();
	}//���������һ��
}

