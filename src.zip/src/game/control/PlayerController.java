/**
 * 
 */
package game.control;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 * @author wangyao
 *��ҿ�������������Ϸ�пأ������¼�
 */
//���̼����ӿ�
public class PlayerController extends KeyAdapter{
	private GameController controller;
	public PlayerController(GameController controller){
		this.controller=controller;
	}//���̴���������Ϸ����
	@Override
	public void keyPressed(KeyEvent e) {
		// TODO �Զ����ɵķ������
		//		super.keyPressed(e);
		switch(e.getKeyCode()){
		case KeyEvent.VK_LEFT:
			controller.Keyleft();
			//System.out.println("x");
			break;
		case KeyEvent.VK_RIGHT:
			controller.Keyright();
			break;
		case KeyEvent.VK_DOWN:
			controller.Keydown();
			break;		
		case KeyEvent.VK_UP:
			controller.keyup();
			break;
		case KeyEvent.VK_SPACE:
			controller.keyspace();
		break;
		
		
		case KeyEvent.VK_A:
			controller.Keyleft1();
			//System.out.println("x");
			break;
		case KeyEvent.VK_D:
			controller.Keyright1();
			break;
		case KeyEvent.VK_S:
			controller.Keydown1();
			break;		
		case KeyEvent.VK_W:
			controller.keyup1();
			break;
		case KeyEvent.VK_X:
			controller.keyspace1();
			break;
		case KeyEvent.VK_P:
			controller.keypause();
			break;
		}
	}

}
