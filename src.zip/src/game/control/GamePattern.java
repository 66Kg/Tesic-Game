/**
 * 
 */
package game.control;

/**
 * @author wangyao
 *
 */
public enum GamePattern {

	Single,
	Double,
	Server,
	Client
}
