package game.util;

import game.view.Player;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class PlayerRecord {
	//�½�������
	public static ArrayList<Player> arrayList=new ArrayList<Player>();
	
	//��ȡ����
	static{
			try {
		  		FileReader fr = new FileReader("cfgs/paihang.txt");
		  	    BufferedReader bufr=new BufferedReader(fr);
			    String s=null;
			    while((s=bufr.readLine())!=null){			    	
			    	String[] ss=new String[2];
			    	 ss=s.split(":");
			    	Player player =new Player();
			    	player.setName(ss[0]);
			    	player.setScore(Integer.valueOf(ss[1]));
			    	arrayList.add(player);
			    	
			    }
			    bufr.close();
			    fr.close();
			    
			} catch (Exception e) {
			// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
	}
	public static void setPlayer(Player p){
	    arrayList.add(p); 	
	    write();
	    
	    
	}
	//��������ֵһ��Ϊ���޸��տ�ʼ�����а��¼bug
	public static Player getPlayer(int i){
		rankPlayers();
		return arrayList.get(i);
	
		
	}
	//д������
	public static void write(){
		File file=new File("cfgs/paihang.txt");
		   try {	   
			FileWriter fileWriter=new FileWriter(file);
			BufferedWriter bufw=new BufferedWriter(fileWriter);
			for(int i=0;i<arrayList.size();i++){//�����С������
				bufw.write(arrayList.get(i).getName()+":"+arrayList.get(i).getScore()+"\t\n");
				//System.out.println("x");
				bufw.newLine();
			}
			bufw.close();
			fileWriter.close();
		} catch (IOException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	//ð��������ݵ÷�����ֵ
	public static void rankPlayers(){
		int temp;
		String name;
		for(int i=1;i<arrayList.size();i++){
			for(int j=0;j<arrayList.size()-i;j++){
				if(Integer.valueOf(arrayList.get(j).getScore())<Integer.valueOf(arrayList.get(j+1).getScore())){
					temp=Integer.valueOf(arrayList.get(j).getScore());
					name=arrayList.get(j).getName();
					arrayList.get(j).setName(arrayList.get(j+1).getName());
					arrayList.get(j).setScore(arrayList.get(j+1).getScore());
					arrayList.get(j+1).setName(name);
					arrayList.get(j+1).setScore(temp);
					}
			}
			
		}
	}

	
}
