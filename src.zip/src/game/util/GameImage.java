/**
 * 
 */
package game.util;

import game.config.GameConfig;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.management.loading.PrivateClassLoader;
import javax.swing.ImageIcon;
import javax.swing.plaf.basic.BasicBorders.SplitPaneBorder;

/**
 * @author wangyao
 *��ϷͼƬ���м�����Ϸ���õ���ͼƬ
 */
public class GameImage {
private static Image window;//���߿�
private static Image player;
private static Image[] BGImage;
private static Image level;
private static Image lines;
private static Image socre;
private static Image numbers;
private static Image progress;
private static Image over;
private static Image pause;
private static Image flashes;
private static Image minos;//����8��СͼƬ
private static Image [] numImages;
private static Image[] minoImages;
private static Image[] flashImages;

	 static{
		pause=new ImageIcon(GameConfig.getSkinPath()+"/game/pause.gif").getImage();
	    over=(new ImageIcon(GameConfig.getSkinPath()+"/game/stop.gif").getImage());
		window=new ImageIcon(GameConfig.getSkinPath()+"/game/window.png").getImage();//��/��б��\\
		player=new ImageIcon(GameConfig.getSkinPath()+"/strings/player.png").getImage();
		flashes=new ImageIcon(GameConfig.getSkinPath()+"/game/flash.png").getImage();
		numbers=new ImageIcon(GameConfig.getSkinPath()+"/strings/numbers.png").getImage();
		progress=new ImageIcon(GameConfig.getSkinPath()+"/game/process.png").getImage();
		lines=new ImageIcon(GameConfig.getSkinPath()+"/strings/Lines.png").getImage();
		level=new ImageIcon(GameConfig.getSkinPath()+"/strings/level.png").getImage();
		socre=new ImageIcon(GameConfig.getSkinPath()+"/strings/points.png").getImage();
		minos=new ImageIcon(GameConfig.getSkinPath()+"/game/square.png").getImage();
		BGImage=new Image[10];
		for(int i=1;i<=10;i++){
			String name=String.format("%s/bgimg/bg_%02d.png", GameConfig.getSkinPath(), i);
			BGImage[i-1]=new ImageIcon(name).getImage();
		
	}
		numImages=new Image[10];
		split(numImages,numbers,2,4);//�ָ�����ͼƬ
		minoImages=new Image[8];
		split(minoImages, minos, 4, 4);//�ָ�С����ͼƬ
		flashImages=new Image[8];
		split(flashImages, flashes, 4, 4);
		
	}//��̬���췽��1������2���޷���ֵ3���޷�����4���޲�
	public static Image getprogress() {
		return progress;
	}
	//����
	public static void reSet(){
		pause=new ImageIcon(GameConfig.getSkinPath()+"/game/pause.gif").getImage();
		over=(new ImageIcon(GameConfig.getSkinPath()+"/game/stop.gif").getImage());
		window=new ImageIcon(GameConfig.getSkinPath()+"/game/window.png").getImage();//��/��б��\\
		player=new ImageIcon(GameConfig.getSkinPath()+"/strings/player.png").getImage();
		flashes=new ImageIcon(GameConfig.getSkinPath()+"/game/flash.png").getImage();
		numbers=new ImageIcon(GameConfig.getSkinPath()+"/strings/numbers.png").getImage();
		progress=new ImageIcon(GameConfig.getSkinPath()+"/game/process.png").getImage();
		lines=new ImageIcon(GameConfig.getSkinPath()+"/strings/Lines.png").getImage();
		level=new ImageIcon(GameConfig.getSkinPath()+"/strings/level.png").getImage();
		socre=new ImageIcon(GameConfig.getSkinPath()+"/strings/points.png").getImage();
		minos=new ImageIcon(GameConfig.getSkinPath()+"/game/square.png").getImage();
		BGImage=new Image[10];
		for(int i=1;i<=10;i++){
			String name=String.format("%s/bgimg/bg_%02d.png", GameConfig.getSkinPath(), i);
			BGImage[i-1]=new ImageIcon(name).getImage();
		
	}
		numImages=new Image[10];
		split(numImages,numbers,2,4);//�ָ�����ͼƬ
		minoImages=new Image[8];
		split(minoImages, minos, 4, 4);//�ָ�С����ͼƬ
		flashImages=new Image[8];
		split(flashImages, flashes, 4, 4);
	}
	private static void split(Image[] images, Image img,  int w,
			int h) {
		// TODO �Զ����ɵķ���������ͼƬ
		int sw=img.getWidth(null)/images.length;
		int sh=img.getHeight(null);
		int iw=w*GameConfig.getUnit();
		int ih=h*GameConfig.getUnit();
		//images=new Image[len];//���������ڴ�
		for (int i=0;i<images.length;i++){
			BufferedImage temp =new BufferedImage(iw, ih, BufferedImage.TYPE_INT_ARGB);
		Graphics g=temp.getGraphics();
		g.drawImage(img, 0, 0, iw, ih, 
				i*sw, 0, (i+1)*sw, sh, null);
		images[i]=temp;
		}
		
	}
	public static Image[] getNumImgs() {
		return numImages;
	}
	public static Image getflashImages(int index) {
		return flashImages[index];
	}

	public static Image getlines() {
		return lines;
	}
	public static Image getsocre() {
		return socre;
	}
	public static Image getlevel() {
		return level;
	}
	public static Image getplayer() {
		return player;
	}
	public static Image getBG(int index) {
		return BGImage[index%10];
	}
	public static Image getWindow() {
		return window;
	}
	public static Image getMinos() {
		return minos;
	}
	public static Image getMinoImage(int index) {//int index��������
		return minoImages[index];
	}
	public static Image getOver() {
		return over;
	}
	public static void setOver(Image over) {
		GameImage.over = over;
	}
	public static Image getPause() {
		return pause;
	}
	public static void setPause(Image pause) {
		GameImage.pause = pause;
	}


}
