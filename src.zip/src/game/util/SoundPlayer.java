package game.util;

import java.io.FileInputStream;
import java.io.InputStream;

import org.omg.CORBA.PRIVATE_MEMBER;

import sun.audio.*;

public class SoundPlayer {
	private static boolean sound = true;
	private static boolean bgmusic = true;
	private static ContinuousAudioDataStream cads;
	
	public static boolean isSound() {
		return sound;
	}

	public static void setSound(boolean sound) {
		SoundPlayer.sound = sound;
	}

	public static boolean isBgmusic() {
		return bgmusic;
	}

	public static void setBgmusic(boolean bgmusic) {
		SoundPlayer.bgmusic = bgmusic;
	}
	
	public static void play(String name){
		if(!sound)return;
		try {
			InputStream file = new FileInputStream(String.format("music/%s.wav", name));
			AudioStream as = new AudioStream(file);
			AudioPlayer.player.start(as);
		} catch (Exception e) {}
	}
	
	public static void playLoop(){
		if(bgmusic)
			playBgmusic();
		else
			stopBgmusic();
	}
	
	private static void playBgmusic(){
		if(cads == null){
			try (InputStream file = new FileInputStream("music/bg.wav")){
				AudioStream as = new AudioStream(file);
				AudioData data = as.getData();
				cads = new ContinuousAudioDataStream(data);
			} catch (Exception e) {}
		}
		AudioPlayer.player.start(cads);
	}
	
	private static void stopBgmusic(){
		if(cads != null)
			AudioPlayer.player.stop(cads);
	}
}
