/**
 * ��ȡ����ͼƬ
 */
package game.util;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

/**
 * @author wangyao
 *
 */
public class DigitImage {
//	private static Image[] imgs;
//	private static int iw;
//	private static int ih;
	
 public static Image getImage(int value){
	 //int bits=(int)Math.log10(value)+1;//��ʮΪ����������ת��Ϊ�ַ���
	 Image[]imgs=GameImage.getNumImgs(); 
	 int bits=String.valueOf(value).length();
	 if(bits==1){
		 return imgs[value];
	 }
	 int iw=imgs[0].getWidth(null);
	 int ih=imgs[0].getHeight(null);
			 
	BufferedImage img=new BufferedImage(iw*bits, ih, BufferedImage.TYPE_INT_ARGB);
	int n=bits-1;
	Graphics g=img.getGraphics();
	while(value!=0){
		int x= value%10;
		Image number=imgs[x];
		g.drawImage(number,iw*n,0,null);
		value/=10;
		n--;
	} 
	return img;

 }
	
}
