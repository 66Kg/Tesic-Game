/**
 * 
 */
package game.view;

import game.control.GameController;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.omg.CORBA.PUBLIC_MEMBER;

import com.sun.org.apache.regexp.internal.REDebugCompiler;



/**
 * @author wangyao
 *
 */
public class Framewelcome extends JFrame{
	public void welcomeJFrame(){
		final JFrame jFrame=new JFrame();
		jFrame.setTitle("��ӭ����");
		jFrame.setSize(600,400);
		jFrame.setLocationRelativeTo(null);
		jFrame.setVisible(true);
        ImageIcon img=new ImageIcon("images\\default\\game\\wel.jpg");
        JLabel label=new JLabel(img);
        label.setBounds(0,0,img.getIconWidth(),img.getIconHeight());
        jFrame.getLayeredPane().add(label,new Integer(Integer.MIN_VALUE));//��ȡframe���ϲ�������ñ���
        JPanel jPanel=(JPanel)jFrame.getContentPane();
        jPanel.setOpaque(false);//����͸��
        JPanel jPanel2=new JPanel();
        jPanel2.setOpaque(false);
        jPanel2.setLayout(null);//Ϊʹ��ť��λ
		JButton button=new JButton("������Ϸ");
		JButton button1=new JButton("�˳�");
		button1.setSize(100, 50);
        button1.setLocation(450, 250);
        button1.setForeground(Color.BLACK); 
        button1.setContentAreaFilled(false);
		button.setSize(100, 50);
        button.setLocation(450, 100);
        button.setForeground(Color.BLACK); 
        button.setContentAreaFilled(false);
		jPanel2.add(button);
		jPanel2.add(button1);
		jFrame.add(jPanel2);
		jFrame.setResizable(false);	
		button1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO �Զ����ɵķ������
				System.exit(0);
			}
		});
		button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
		
				GameController game=new GameController();
				game.showwindow();
				jFrame.dispose();
				// TODO �Զ����ɵķ������
				
			}
		});
		
	}

}
