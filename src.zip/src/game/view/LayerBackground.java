/**
 * 
 */
package game.view;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.text.ChangedCharSetException;

import game.config.CanvasConfig;
import game.config.GameConfig;
import game.model.GameRecord;
import game.util.GameImage;

/**
 * @author wangyao
 *������
 */
public class LayerBackground extends Layer{
	private int player;
	public LayerBackground(int x, int y,int player) {
		super(x, y,player);
		// TODO �Զ����ɵĹ��캯�����
		this.player=player;
	width=CanvasConfig.getWidth();
	height=CanvasConfig.getHeight();
	border=false;
	}

	@Override
	protected void drawContentArea(Graphics g) {
		GameRecord r=FrameGame.getCarrier()[player].getRecord();
		
		Image img=GameImage.getBG(r.getLevel());//�ӵ�һ�ſ�ʼ��ȡ
		g.drawImage(img,x,y,width,height,null);

		
	}



	

}
