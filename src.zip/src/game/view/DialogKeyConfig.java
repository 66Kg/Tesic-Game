/**
 * 
 */
package game.view;

import java.awt.FlowLayout;
import java.awt.Frame;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 * @author wangyao
 *�������öԻ��򣬿����޸Ĺ��ܶ�Ӧ�İ���������
 */
public class DialogKeyConfig extends  JDialog{
	private static final long serialVersionUID = 1L;
	public DialogKeyConfig(Frame owner){
		super(owner,true);//ģʽ���ڣ���ѯ��ģʽ����
		InitializerComponets();
	}
	private void InitializerComponets() {
		// TODO �Զ����ɵķ������
		JLabel lbImageJLabel=new JLabel("�������ã���");
//		lbImageJLabel.setBounds(40,40,30,20);
		JTextField txt=new JTextField(10);
		txt.setBounds(20, 20,50, 50);
		  FlowLayout seeText=new FlowLayout(FlowLayout.CENTER);
		  seeText.setHgap(20);
		  seeText.setVgap(60);
		this.setLayout(seeText);
		this.add(lbImageJLabel);	
		this.add(txt);
		
		JLabel lbImageJLabe2=new JLabel("�������ã���");
		lbImageJLabel.setBounds(40,40,30,20);
		JTextField txt2=new JTextField(10);
		txt.setBounds(20, 20,50, 50);
		  FlowLayout seeText2=new FlowLayout(FlowLayout.CENTER);
		  seeText2.setHgap(20);
		  seeText2.setVgap(60);
		this.setLayout(seeText2);
		this.add(lbImageJLabe2);	
		this.add(txt2);
		
		JLabel lbImageJLabe3=new JLabel("�������ã���");
		lbImageJLabel.setBounds(40,40,30,20);
		JTextField txt3=new JTextField(10);
		txt.setBounds(20, 20,50, 50);
		  FlowLayout seeText3=new FlowLayout(FlowLayout.CENTER);
		  seeText3.setHgap(20);
		  seeText3.setVgap(60);
		this.setLayout(seeText3);
		this.add(lbImageJLabe3);	
		this.add(txt3);
		
		JLabel lbImageJLabe4=new JLabel("�������ã���");
		lbImageJLabel.setBounds(40,40,30,20);
		JTextField txt4=new JTextField(10);
		txt.setBounds(20, 20,50, 50);
		  FlowLayout seeText4=new FlowLayout(FlowLayout.CENTER);
		  seeText4.setHgap(20);
		  seeText4.setVgap(60);
		this.setLayout(seeText4);
		this.add(lbImageJLabe4);	
		this.add(txt4);
		
		this.setTitle("��������");
		this.setSize(400,300);
		this.setLocationRelativeTo(super.getOwner());
	}

}
