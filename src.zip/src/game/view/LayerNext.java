/**
 * 
 */
package game.view;

import game.config.GameConfig;
import game.model.DataCarrier;
import game.model.TetrisBrick;
import game.model.TetrisMino;
import game.model.TetrisMinoFactory;
import game.util.DigitImage;

import java.awt.Graphics;
import java.awt.Image;

/**
 * @author wangyao
 *��ʾ������²㷽��
 */
public class LayerNext extends Layer {
private int player;
	public LayerNext(int x, int y,int player) {
		super(x, y,player);
		// TODO �Զ����ɵĹ��캯�����
		width=6*GameConfig.getCellSize()+GameConfig.getUnit()*2;
		height=4*GameConfig.getCellSize()+GameConfig.getUnit()*2;
		cw=width-2*GameConfig.getUnit();
		ch=height-2*GameConfig.getUnit();
		this.player=player;
	}

	@Override
	protected void drawContentArea(Graphics g) {
		// TODO �Զ����ɵķ������

		// TODO �Զ����ɵķ������
		TetrisMino mino=FrameGame.getCarrier()[player].getNext();
		if(mino==null)return;
		
	     for(TetrisBrick brick:mino.getBricks()){
		Image img=brick.getImage();
		int dx=cx+(cw-mino.getWidth())/2+brick.getLeft();//x1+(x2-x1)/2
		int dy=cy+(ch-mino.getHeight())/2+brick.getTop();
		g.drawImage(img, dx, dy, null);}
	
		
	}

}
