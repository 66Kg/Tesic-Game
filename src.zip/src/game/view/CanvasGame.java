/**
 * 
 */
package game.view;

import game.config.CanvasConfig;
import game.config.LayerConfig;
import game.model.DataCarrier;

import java.awt.Graphics;
import java.lang.reflect.Constructor;

import javax.swing.JPanel;

/**
 * @author wangyao
 *��Ϸ�����࣬��װ����ͼ�㣬��������
 */
public class CanvasGame extends JPanel{
	private Layer [] layers;
	
	public CanvasGame(){
		layers=new Layer[CanvasConfig.getLayers().size()];
		for(int i=0;i<layers.length;i++){
			LayerConfig cfg=CanvasConfig.getLayers().get(i);
			try {
				//System.out.println(cfg.getPlayer());
				Class<?>cls=Class.forName(cfg.getClassName());
				Constructor<?>ctor=cls.getConstructor(int.class,int.class,int.class);//�ڶ�̬�������ҹ��췽��Ϊ���������ķ���
				layers[i]=(Layer)ctor.newInstance(cfg.getX(),cfg.getY(),cfg.getPlayer());//carrier���ݲ���

			} catch (Exception e) {
				// TODO: handle exception
			}
		}
//		layers[0] = new LayerGame(2,2);//x,y,w,g
//		layers[1] = new LayerNext(46,2);
//		layers[2] = new Layerlnfomation(46,26);
		
	}
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		//System.out.println(layers.length);
		for(Layer layer : layers){
			layer.draw(g);
			//System.out.println(layers.length);
	}

}}
