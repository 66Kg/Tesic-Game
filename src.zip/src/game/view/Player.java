/**
 * 
 */
package game.view;

import game.model.DataCarrier;

import java.util.ArrayList;

/**
 * @author wangyao
 *
 */
public class Player {
	
	private  String name;
	private int score;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}

}
