/**
 * 
 */
package game.view;

import game.config.CanvasConfig;
import game.config.GameConfig;
import game.control.GameController;
import game.control.PlayerController;
import game.model.DataCarrier;
import game.model.TetrisMino;
import game.model.TetrisServer;
import game.util.GameImage;
import game.util.SoundPlayer;

import java.awt.Component;
import java.awt.Frame;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**��Ϸ������
 * @author wangyao
 *
 */
public class FrameGame extends JFrame{
	private ResourceBundle bundle;
	private PlayerController player;
	private static DataCarrier carrier[];
	private CanvasGame view;
	private TetrisServer server[];
	private JMenuItem item;
	public FrameGame(DataCarrier[] carrier,TetrisServer[]  server){
		this.server=server;
		view=new CanvasGame();
		FrameGame.carrier=carrier;
		bundle =ResourceBundle.getBundle("game.resource.dict",
		new  Locale(GameConfig.getLanguage()));//������ѡ��
//����������Դ��Locale.ENGLISH
		initializeComponents();
		try{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsClassicLookAndFeel");
			SwingUtilities.updateComponentTreeUI(this);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static DataCarrier[]  getCarrier() {
		return carrier;
		
	}
	private class DiaLogRecordsHandler implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO �Զ����ɵķ������
			DiaLogRecords records=new DiaLogRecords(FrameGame.this);
			records.setVisible(true);
		}
		
	}
	public void addStartListener(ActionListener listener){
		item.addActionListener(listener);
	}
	//��Ϸ�˳���������
    private class ExitHandler implements ActionListener
    {
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO �Զ����ɵķ������
			GameConfig.save();
			System.exit(0);
		}
    	
    }
   //������˫���л�
    private class PatternHandler implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			JRadioButtonMenuItem modelGroup=(JRadioButtonMenuItem)e.getSource();
		    if(modelGroup.getName().equals("Double")){			
			GameConfig.setPattern("Double");
			FrameGame.this.dispose();
			carrier[1]= new DataCarrier();	
			server[1] = new TetrisServer(carrier[1]);
			CanvasConfig.Rest();//���������ļ�
			view=new CanvasGame();
			//FrameGame.this.repaint();
			FrameGame.this.setVisible(true);
			Insets margin=FrameGame.this.getInsets();//������ʾ����������
			FrameGame.this.setSize(CanvasConfig.getWidth()+margin.left+margin.right,CanvasConfig.getHeight()+margin.top+margin.bottom+FrameGame.this.getJMenuBar().getHeight());
			FrameGame.this.setLocationRelativeTo(null);//���ô�������Ļ����
			FrameGame.this.requestFocus();//��ͼ�����뽹��	
			FrameGame.this.show();
			FrameGame.this.repaint();
			FrameGame.this.setContentPane(view);
	
			
		}
		else if (modelGroup.getName().equals("Single")) {
			GameConfig.setPattern("Single");
			FrameGame.this.dispose();
			carrier[1]=null;
			server[1]=null;
			CanvasConfig.Rest();
			view=new CanvasGame();
			//FrameGame.this.repaint();
			FrameGame.this.setVisible(true);
			Insets margin=FrameGame.this.getInsets();//������ʾ����������
			FrameGame.this.setSize(CanvasConfig.getWidth()+margin.left+margin.right,CanvasConfig.getHeight()+margin.top+margin.bottom+FrameGame.this.getJMenuBar().getHeight());
			FrameGame.this.setLocationRelativeTo(null);//���ô�������Ļ����
			FrameGame.this.requestFocus();//��ͼ�����뽹��	
			FrameGame.this.show();
			FrameGame.this.repaint();
			FrameGame.this.setContentPane(view);

			
			
	
			
		}
}
    	
    }
    private class BgmusicHandler implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO �Զ����ɵķ������
			
		SoundPlayer.setBgmusic(!SoundPlayer.isBgmusic());
		if(FrameGame.carrier[0].getCurrent()!=null){
			SoundPlayer.playLoop();
		}
		}
    	
    }
    public class keySoundHandler implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO �Զ����ɵķ������
			SoundPlayer.setSound(!SoundPlayer.isSound());
			
		}}
    private class skinHandler implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			JRadioButtonMenuItem jb = (JRadioButtonMenuItem)e.getSource();
			if(jb.getName().equals("Cartoon")){
				GameConfig.setSkinPath("images/cartoon");
				GameImage.reSet();
				FrameGame.this.repaint();
			}
			else {
				GameConfig.setSkinPath("images/default");
				GameImage.reSet();
				FrameGame.this.repaint();
			}
			
		}
    	
    }
    private class AboutHandler implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO �Զ����ɵķ������
			DialogAbout about=new DialogAbout(FrameGame.this);
			about.setVisible(true);
		}
    	
    }
    private class KeyconfigHandler implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO �Զ����ɵķ������
			DialogKeyConfig keyConfig=new DialogKeyConfig(FrameGame.this);
			keyConfig.setVisible(true);
			
		}}
    private class Language implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO �Զ����ɵķ������
			JMenuItem item5=(JMenuItem)e.getSource();//����¼�Դ
			GameConfig.setLanguage(item5.getName());
			//if(item5.getName().equals("English"))
			bundle =ResourceBundle.getBundle("game.resource.dict", new Locale(item5.getName()));
			//else
			//bundle =ResourceBundle.getBundle("game.resource.dict",Locale.CHINESE);
			localize();
				
		}
    }
   //������Ӱ��ť
    private class ManulHandler implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO �Զ����ɵķ������
       LayerGame.setOpen(!LayerGame.getOpen());
		if (FrameGame.carrier[0].getCurrent()!=null) {
			LayerGame.getOpen();			
		}
			}
		}
    	
    
		private void localize() {
			// TODO �Զ����ɵķ������
			this.setTitle(bundle.getString("Title"));
			JMenuBar bar=this.getJMenuBar();
			for(int i=0;i<bar.getMenuCount();i++){
				JMenu menu =bar.getMenu(i);
			localizeMenu(menu);
			}
				
		}
        private void localizeMenu(JMenu menu){
        	menu.setText(bundle.getString(menu.getName()));
        	for(int i=0;i<menu.getItemCount();i++){
        		JMenuItem item =menu.getItem(i);
        		if(item==null)
        			continue;
        		item.setText(bundle.getString(item.getName()));
        		if(item instanceof JMenu) localizeMenu((JMenu)item);
        			
        	}
        		
        	}
        

    	
    
//    private class Language2 implements ActionListener{
//
//		@Override
//		public void actionPerformed(ActionEvent e) {
//			// TODO �Զ����ɵķ������
//			bundle =ResourceBundle.getBundle("game.resource.dict");
//		}
//    	
//    }
	
	private void initializeComponents() {
		// TODO �Զ����ɵķ������
		this.setContentPane(view);//����Ϸ��������Ϊ��������
		this.setJMenuBar(createBar());
		this.setTitle(bundle.getString("Title")); //�����������Դ��resourcebundle��ȡ
//		this.setSize(450, 600);
		this.setLocationRelativeTo(null);//���ô�������Ļ����
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		//this.setAlwaysOnTop(true);	
		
	}
	
	private JMenuBar createBar() {
		// TODO �Զ����ɵķ������
		JMenuBar bar= new JMenuBar();
		//------------------��Ϸ�˵�����--------------------//
		JMenu menuGame=new JMenu(bundle.getString("Game"));//��������Դ����ȡ
		bar.add(menuGame);
	    menuGame.setName("Game");
		item = new JMenuItem(bundle.getString("New"));
		item.setMnemonic('N');//���ò˵��ȼ�
		item.setAccelerator(KeyStroke.getKeyStroke("F2"));//���ÿ�ݼ�
		item.setName("New");//������ʻ�
		//---------------------Model----------------------------//
		JMenu mod= new JMenu(bundle.getString("Model"));
		mod.setName("Model");
		
		mod.setMnemonic('M');
		ButtonGroup modelGroup= new ButtonGroup()
		;
		JRadioButtonMenuItem jradio= new JRadioButtonMenuItem(bundle.getString("Single"));
		jradio.setSelected(GameConfig.getLanguage().equals("Single"));
		jradio.addActionListener(new PatternHandler());
		jradio.setName("Single");
		jradio.setMnemonic('S');
		modelGroup.add(jradio);
		
		JRadioButtonMenuItem jradio2= new JRadioButtonMenuItem(bundle.getString("Double"));
		
		jradio2.setMnemonic('D');
		jradio2.setName("Double");
		modelGroup.add(jradio2);
		jradio2.setSelected(GameConfig.getLanguage().equals("Double"));
		jradio2.addActionListener(new PatternHandler());
		JRadioButtonMenuItem jradio3= new JRadioButtonMenuItem(bundle.getString("Network"));
		jradio3.setName("Network");
		
		modelGroup.add(jradio3);
		//--------------Exit------------//
		JMenuItem exit= new JMenuItem(bundle.getString("Exit"));
		exit.setName("Exit");
		//exit.setMnemonic('E');
		exit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE,0));//Esc�ر�
		exit.addActionListener(new ExitHandler());//�����¼�
		//----------------Rank-----------//
		JMenuItem rank= new JMenuItem(bundle.getString("Rank"));
		rank.setName("Rank");
		rank.setMnemonic('R');
		rank.addActionListener(new DiaLogRecordsHandler());
		//----------------Keycfg-----------//
		JMenuItem key= new JMenuItem(bundle.getString("Keycfg"));
		key.setName("Keycfg");
		key.setMnemonic('K');
		key.addActionListener(new KeyconfigHandler());


		mod.add(jradio);
		mod.add(jradio2);
		mod.add(jradio3);
		menuGame.add(mod);
		menuGame.addSeparator();
		//menuGame.add(jradio);
		//menuGame.add(jradio2);
		menuGame.add(item);
		menuGame.addSeparator();//���ӷָ���
		menuGame.add(rank);
		menuGame.addSeparator();
		menuGame.add(key);
		menuGame.addSeparator();
		menuGame.add(exit);
		//-------------------------------��ͼ�˵�����----------------------//
		JMenu menuview= new JMenu(bundle.getString("View"));
		menuview.setName("View");
		bar.add(menuview);
		
		JMenu item2=new JMenu(bundle.getString("Skin"));
		item2.setMnemonic('S');
		item2.setName("Skin");
		
		ButtonGroup modelGroup2= new ButtonGroup();
		JRadioButtonMenuItem classic= new JRadioButtonMenuItem(bundle.getString("Classic"));
		classic.setMnemonic('C');
		classic.addActionListener(new skinHandler());
		classic.setName("Classic");
		modelGroup2.add(classic);
		
		JRadioButtonMenuItem catton= new JRadioButtonMenuItem(bundle.getString("Cartoon"));
		catton.setMnemonic('O');
		catton.setName("Cartoon");
		catton .addActionListener(new skinHandler());
		modelGroup2.add(catton);
		
		//-----------------BGM-------------//
		JRadioButtonMenuItem bgm= new JRadioButtonMenuItem(bundle.getString("BgMusic"));
		bgm.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_M,ActionEvent.CTRL_MASK));//��ݼ�
		bgm.setName("BgMusic");
		bgm.setMnemonic('B');
		bgm.setSelected(true);
		bgm.addActionListener(new BgmusicHandler());//�����¼�
		//---------------------KeySound--------------------//
		JRadioButtonMenuItem keysound= new JRadioButtonMenuItem(bundle.getString("KeySound"));
		keysound.setName("KeySound");
		keysound.setMnemonic('K');
		keysound.setSelected(true);
		keysound.setAccelerator(KeyStroke.getKeyStroke("F4"));
		keysound.addActionListener(new keySoundHandler());
		
		item2.add(classic);
		item2.add(catton);
		//menuview.add(classic);
		//menuview.add(catton);
		//menuview.addSeparator();
		menuview.add(item2);
		menuview.addSeparator();
		menuview.add(bgm);
		menuview.addSeparator();
		menuview.add(keysound);

		//----------------------------------�����˵�����-----------------------//
		JMenu menuhelp=new JMenu(bundle.getString("Help"));
		menuhelp.setName("Help");
		bar.add(menuhelp);
		//-----------------------------About------------------------------------//
		JMenuItem item3= new JMenuItem(bundle.getString("About"));
		item3.setMnemonic('A');
		item3.setName("About");
		item3.addActionListener(new AboutHandler());
		//------------------------------------Language----------------------------//
		JMenu item4= new JMenu(bundle.getString("Language"));
		item4.setMnemonic('L');
		item4.setName("Language");
		
		ButtonGroup modelGroup3= new ButtonGroup();
		JRadioButtonMenuItem item5 =new JRadioButtonMenuItem(bundle.getString("en"));
		item5.setName("en");
		item5.setSelected(GameConfig.getLanguage().equals("en"));//����ѡ����������
		modelGroup3.add(item5);
		
		item5.addActionListener(new Language());
		
		JRadioButtonMenuItem item6 =new JRadioButtonMenuItem(bundle.getString("zh"));
		item6.setName("zh");
		item6.setSelected(GameConfig.getLanguage().equals("zh"));
		modelGroup3.add(item6);
		
		item6.addActionListener(new Language());
		
		JMenuItem manul= new JMenuItem(bundle.getString("Manual"));
		manul.setMnemonic('M');
		manul.setName("Manual");
		manul.setSelected(true);
		manul.addActionListener(new ManulHandler());
		item4.add(item5);
		item4.add(item6);
		menuhelp.add(item3);
		menuhelp.addSeparator();
		menuhelp.add(item4);
		menuhelp.addSeparator();
		menuhelp.add(manul);
		return bar;
	}

	/**
	 * @param args
	 */


}
