/**
 * 
 */
package game.view;

import game.config.GameConfig;
import game.model.GameRecord;
import game.util.DigitImage;
import game.util.GameImage;

import java.awt.Graphics;
import java.awt.Image;

/**
 * @author wangyao
 *��Ϸ��Ϣ�㣬���Ƶȼ����÷֡�����
 */
public class Layerlnfomation extends Layer {
	private GameRecord r;
	private int player;
	public Layerlnfomation(int x, int y,int player) {
		super(x,y,player);
		// TODO �Զ����ɵĹ��캯�����
		this.player=player;
		width=6*GameConfig.getCellSize()+GameConfig.getUnit()*2;
		height=14*GameConfig.getCellSize()+GameConfig.getUnit()*2;
		cw=width-2*GameConfig.getUnit();
		ch=height-2*GameConfig.getUnit();
	}

	@Override
	protected void drawContentArea(Graphics g) {
		// TODO �Զ����ɵķ������
		drawPlayer(g, 1);
		drawLevel(g,3);
		drawLines(g,6);
		drawSocre(g,9);
		drawProgress(g,12);

	}
	//���ƽ�����
	private void drawProgress(Graphics g, int row) {
		// TODO �Զ����ɵķ������
		Image img=GameImage.getprogress();
		int x1=cx;
		int y1=cy+4*row*GameConfig.getUnit();
		int iw=img.getWidth(null);//ͼƬ����
		int ih=img.getHeight(null);
		int w=24*GameConfig.getUnit();
		int h=4*GameConfig.getUnit();
		g.drawRect(x1, y1, w, h);
		r=FrameGame.getCarrier()[player].getRecord();
		double progress=(r.getLines()-(r.getLevel()-1)*20)/20.0;
		g.drawImage(img, x1+1, y1+1, (int)(w*progress-1)+x1-1, y1+h,//intǿת
				0, 0, (int)(iw*progress-1), ih, null);
	}

	private void drawLines(Graphics g, int row) {
		// TODO �Զ����ɵķ������
		//�Կͻ�ȥ���Ͻ�Ϊ׼��ƫ��+�ͻ������Ͻǵ�����
		Image img=GameImage.getlines();
		int x1=cx;
		int y1=4*row*GameConfig.getUnit()+cy;
		int w=16*GameConfig.getUnit();
		int h=4*GameConfig.getUnit();
		g.drawImage(img,x1, y1, w, h,null);
		r=FrameGame.getCarrier()[player].getRecord();
		Image digit=DigitImage.getImage(r.getLines());
		x1=cw-digit.getWidth(null)+cx;
		y1+=GameConfig.getUnit()*5;
		g.drawImage(digit, x1, y1,null);
	}

	private void drawSocre(Graphics g, int row) {
		// TODO �Զ����ɵķ������
		Image img=GameImage.getsocre();
		int x1=cx;
		int y1=4*row*GameConfig.getUnit()+cy;
		int w=16*GameConfig.getUnit();
		int h=4*GameConfig.getUnit();
		g.drawImage(img,x1, y1, w, h,null);
		r=FrameGame.getCarrier()[player].getRecord();
		Image digit=DigitImage.getImage(r.getScore());
		x1=cw-digit.getWidth(null)+cx;
		y1+=GameConfig.getUnit()*5;
		g.drawImage(digit, x1, y1,null);


	}

	private void drawLevel(Graphics g,int row) {
		// TODO �Զ����ɵķ������
		Image img=GameImage.getlevel();
		int x1=cx;
		int y1=4*row*GameConfig.getUnit()+cy;
		int w=16*GameConfig.getUnit();
		int h=4*GameConfig.getUnit();
		g.drawImage(img,x1, y1, w, h,null);
		r=FrameGame.getCarrier()[player].getRecord();
		//int level=r==null ? 1:r.getLevel();
		Image digit=DigitImage.getImage(r.getLevel());
		x1=cw-digit.getWidth(null)+cx;
		y1+=GameConfig.getUnit()*5;
		g.drawImage(digit, x1, y1,null);
	}

	private void drawPlayer(Graphics g, int row) {
		// TODO �Զ����ɵķ������

		Image img=GameImage.getplayer();
		int x1=4*GameConfig.getUnit()+cx;
		int y1=4*row*GameConfig.getUnit()+cy;
		int w=16*GameConfig.getUnit();
		int h=4*GameConfig.getUnit();
		g.drawImage(img,x1, y1, w, h,null);
	}

}
