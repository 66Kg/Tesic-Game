/**
 * 
 */
package game.view;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JOptionPane;

import game.config.GameConfig;
import game.control.GameController;
import game.model.DataCarrier;
import game.model.MinoColor;
import game.model.TetrisBrick;
import game.model.TetrisMino;
import game.model.TetrisMinoFactory;
import game.model.TetrisServer;
import game.model.TetrisWall;
import game.util.GameImage;
import game.util.PlayerRecord;

/**
 * @author wangyao
 *��Ϸ����������Ϸǽ�����
 */
public class LayerGame extends Layer{
	private int flashCount=0; 
	private int player;
	private DataCarrier carrier;
	private static boolean over;
	private static boolean open=true;
	public LayerGame(int x,int y,int player){
		super(x,y,player);
   //		 System.out.println(player);
		this.player=player;//������Ҷ�
		width=GameConfig.COLS*GameConfig.getCellSize()+GameConfig.getUnit()*2;
		height=GameConfig.ROWS*GameConfig.getCellSize()+GameConfig.getUnit()*2;
		cw=width-2*GameConfig.getUnit();
		ch=height-2*GameConfig.getUnit();

	}

	@Override
	protected void drawContentArea(Graphics g) {
		drawCurrent(g);
		drawWall(g);
		//drawOver(g);
		//Ĭ����Ϊ��Ӱ
		if(open){
		drawLanded(g);}
		if(FrameGame.getCarrier()[player].isOver()){
			  
			drawOver(g);
//			if(FrameGame.getCarrier()[player].isPause()){
//				System.out.println("x");
//				drawPause(g);}
		}
		//System.out.println(player);
	}
	//������

	private  void drawOver(Graphics g) {
		// TODO �Զ����ɵķ������
		Image img=GameImage.getOver();
		int x1=(GameConfig.COLS*GameConfig.getCellSize()+GameConfig.getUnit()*2)/2-GameConfig.getCellSize()*3+GameConfig.getUnit()*2;
		int y1=(GameConfig.ROWS*GameConfig.getCellSize()+GameConfig.getUnit()*2)/2-GameConfig.getCellSize()*2;
		int w=img.getWidth(null);
		int h=img.getHeight(null);
		g.drawImage(img, x1, y1, w, h, null);
	}

	private void drawLanded(Graphics g) {
		//����Ӱ
		TetrisMino mino=FrameGame.getCarrier()[player].getShadow();
	    if(mino==null)return;
	    synchronized (this) {
			    for(TetrisBrick brick:mino.getBricks()){
				Image img=brick.getImage();
				int dw=img.getWidth(null);
				int dh=img.getHeight(null);
				int dx=cx+brick.getLeft();
				int dy=cy+brick.getTop();
				g.drawRect(dx, dy, dw, dh);}
	}
	}

	private void drawWall(Graphics g) {
		// TODO �Զ����ɵķ������
		TetrisWall wall=FrameGame.getCarrier()[player].getWall();
		if(wall==null)return;
		for(TetrisBrick brick:wall.getLandedBricks()){
			Image img=brick.getImage();
			int dx=cx+brick.getLeft();
			int dy=cy+brick.getTop();
			g.drawImage(img, dx, dy, null);
			}
		if(wall.getCompletedRows().length!=0){
			flashLines(wall.getCompletedRows(),g);
		}
	}

	private void flashLines(int [] completedRows, Graphics g) {
		// TODO �Զ����ɵķ������
		    for(int i=0;i<completedRows.length;i++){
			Image imgImage=GameImage.getflashImages(flashCount);
			int dx=cx;
			int dy=cy+completedRows[i]*4*GameConfig.getUnit();
			int dw=cw;
			int dh=imgImage.getHeight(null);
					g.drawImage(imgImage, dx, dy, dw,dh, null);
					
		}
		   flashCount++;
		  if(flashCount==8){
			flashCount=0;
			TetrisWall wall=FrameGame.getCarrier()[player].getWall();
			wall.removeLines();
		}
		
	}

	private void drawCurrent(Graphics g) {
		// TODO �Զ����ɵķ������������
		TetrisMino mino=FrameGame.getCarrier()[player].getCurrent();
	 if(mino==null)return;
	 
			for(TetrisBrick brick:mino.getBricks()){
				Image img=brick.getImage();
				int dx=cx+brick.getLeft();
				int dy=cy+brick.getTop();
				g.drawImage(img, dx, dy, null);}
			

	 }

	public static boolean getOpen() {
		return open;
	}

	public static boolean setOpen(boolean open) {
		LayerGame.open = open;
		return open;
	}


	
	}


